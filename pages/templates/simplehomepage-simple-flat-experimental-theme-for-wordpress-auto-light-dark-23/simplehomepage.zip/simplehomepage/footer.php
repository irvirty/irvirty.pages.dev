<?php
//<!-- page: footer.php -->
?>

</div>
</main>

<footer class="margin3List">
<div class="margin3 padding3"></div>


<?php if ( is_active_sidebar( 'simplehomepage-sidebar-2' ) ) : ?>
<div class="tLeft wrapper2">
<aside>
	<div id="simplehomepage-sidebar-2" class="primary-sidebar widget-area" role="complementary">
		<?php dynamic_sidebar( 'simplehomepage-sidebar-2' ); ?>
	</div><!-- #sidebar -->
</aside>
</div>
<?php endif; ?>


<nav class="tCenter">

<a class="padding brand" style="padding-left: 0;" href="<?php bloginfo('rss2_url'); ?>">RSS</a>
<!--<a class="padding brand" href="#">link example</a>
<a class="padding brand" href="#">link example</a>-->
<!--<span class="gray">Theme license:</span> <a class="brand inlineBlock padding" rel="license" href="https://creativecommons.org/licenses/by-sa/4.0/">CC BY-SA 4.0 *</a>-->
<span class="op padding small" style="padding-right: 0;"><!--2024-->2025</span>
</nav>
</footer>

	<!-- All the document's HTML goes first. -->
	<!-- Then last, before closing the body tag, add: -->
<?php wp_footer(); ?>
</body>
</html>


