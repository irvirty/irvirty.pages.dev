
<?php
/*
the_post_thumbnail_url();
*/


/*
the_title();
the_excerpt();

the_date();
comments_number();
the_permalink();

comments_template();
*/


?>

<article>
<div class="bgList border3List borderRadius2 padding3 tLeft">
<h2><a href="<?=get_permalink()?>"><?=the_title(); ?></a></h2>
<?php
//the_excerpt();
the_content();
?>

<div class="postFooter break2 small">
<span class="tagList tLeft left"><?php the_category( ', ' ).the_tags('<span> / ', ', ', '</span>'); ?></span>
<span class="tagList tRight right">
<?PHP
if (!is_page()){
//https://stackoverflow.com/questions/4290420/wordpress-how-to-check-whether-it-is-post-or-page
echo '<a class="block tRight" href="'.get_permalink().'">'.get_the_date().' ('.get_comments_number().')</a>';
} else {
echo '<a class="block tRight"></a>';
}
?>
</span>
</div>

</div>
</article>

<?php
/*<div class="padding smaller gray"><?php comments_number(); ?></div>*/
//comments_number();
//comments_template();
?>
