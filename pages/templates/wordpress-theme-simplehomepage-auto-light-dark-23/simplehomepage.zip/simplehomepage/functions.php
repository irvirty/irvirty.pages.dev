<?php

/*add_action('after_setup_theme', 'wpdocs_theme_setup');

function wpdocs_theme_setup(){
    load_theme_textdomain('simple-home-page', get_template_directory() . '/languages');
}
*/


function mytheme_theme_support(){
// Adds dynamic title tag support
add_theme_support("title-tag");
add_theme_support("custom-logo");
add_theme_support("post-thumbnails");
add_theme_support("automatic-feed-links");

add_theme_support("align-wide");
add_theme_support("responsive-embeds");

//add_theme_support( 'custom-background' );
//add_theme_support( 'custom-header' );
add_theme_support("wp-block-styles");

add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption', 'style', 'script' ) );
}

add_action('after_setup_theme','mytheme_theme_support');


//https://developer.wordpress.org/reference/functions/add_editor_style/
/**
 * Registers an editor stylesheet for the theme.
 */
function wpdocs_theme_add_editor_styles() {
add_editor_style( 'custom-editor-style.css' );
}
add_action( 'admin_init', 'wpdocs_theme_add_editor_styles' );



/*delme
add_action( 'enqueue_block_editor_assets', 'themeslug_block_editor_assets' );

function themeslug_block_editor_assets() {
    wp_enqueue_script(
        'themeslug-block-editor',
        get_theme_file_uri( 'assets/js/block-editor.js' ),
        array( 
            'wp-blocks', 
            'wp-dom-ready', 
            'wp-edit-post' 
        )
    );
}
*/

//https://developer.wordpress.org/reference/functions/register_block_style/
if ( function_exists( 'register_block_style' ) ) {
register_block_style(
        'core/quote',
        array(
            'name'         => 'blue-quote',
//'label'        => __( 'Blue Quote', 'textdomain' ),
'label'        => 'Blue Quote',
            'is_default'   => true,
            'inline_style' => '.wp-block-quote.is-style-blue-quote { color: var(--blue); }',
        )
    );
}






/*
//https://stackoverflow.com/questions/74862933/how-to-manually-create-a-text-domain-for-a-wordpress-child-theme
function mychildtheme_load_textdomain() {
load_child_theme_textdomain( 'simplehomepage', get_stylesheet_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'mychildtheme_load_textdomain' );
*/


function mytheme_menus(){
$locations = array(
'primary' => "Desktop Primary Menu",
//'footer' => "Footer Menu Items"
);

register_nav_menus($locations);
}

add_action('init', 'mytheme_menus');


function mytheme_register_styles(){

$varsion = wp_get_theme()->get('Version');
//wp_enqueue_style('main', get_template_directory_uri()."/assets/css/main.css",  array(), '1.0.0', 'all');
wp_enqueue_style('main', get_template_directory_uri()."/assets/css/main.css",  false, '1.0.0', 'all');
wp_enqueue_style('auto', get_template_directory_uri()."/assets/css/auto.css",  false, '1.0.0', 'all');
wp_enqueue_style('style', get_template_directory_uri()."/style.css",  false, '1.0.0', 'all');
}

add_action('wp_enqueue_scripts', 'mytheme_register_styles');


function mytheme_register_scripts(){
wp_enqueue_script('main', get_template_directory_uri()."/assets/js/main.js",  array(), '1.0.0', 'all');
}

add_action('wp_enqueue_scripts', 'mytheme_register_scripts');






/*
function mytheme_widget_areas(){

register_sidebar(
array(
'before_title' => '',
'after_title' => '',
'before_widget' => '',
'after_widget' => '',
),
array(
'name' => 'Sidebar Area',
'id' => 'sidebar-1',
'description' => 'Sidebar Widget Area',
)
);
}

add_action('widgets_init', 'mytheme_widget_areas');
*/



/**
 * Add a sidebar.
 */
//https://developer.wordpress.org/reference/functions/register_sidebar/
// Top Sidebar
function wpdocs_theme_slug_widgets_init() {
	register_sidebar( array(
//		'name'          => __( 'Main Sidebar', 'textdomain' ),
		'name'          => 'Top Sidebar',
		'id'            => 'sidebar-1',
//		'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'textdomain' ),
		'description'   => 'Widgets in this area will be shown on all posts and pages.',
//		'before_widget' => '<li id="%1$s" class="widget %2$s">',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
//		'after_widget'  => '</li>',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="widgettitle bold h2">',
		'after_title'   => '</div>',
	) );
}

add_action( 'widgets_init', 'wpdocs_theme_slug_widgets_init' );

// Bottom Sidebar
function wpdocs_theme_slug_widgets_init_2() {
	register_sidebar( array(
//		'name'          => __( 'Main Sidebar', 'textdomain' ),
		'name'          => 'Bottom Sidebar',
		'id'            => 'sidebar-2',
//		'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'textdomain' ),
		'description'   => 'Widgets in this area will be shown on all posts and pages.',
//		'before_widget' => '<li id="%1$s" class="widget %2$s">',
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
//		'after_widget'  => '</li>',
		'after_widget'  => '</div><div class="margin2 padding2"></div>',
		'before_title'  => '<h2 class="widgettitle">',
		'after_title'   => '</h2>',
	) );
}

add_action( 'widgets_init', 'wpdocs_theme_slug_widgets_init_2' );




