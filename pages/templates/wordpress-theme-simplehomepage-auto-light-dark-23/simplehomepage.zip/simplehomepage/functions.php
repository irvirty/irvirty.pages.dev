<?php

/*add_action('after_setup_theme', 'wpdocs_theme_setup');

function wpdocs_theme_setup(){
    load_theme_textdomain('simple-home-page', get_template_directory() . '/languages');
}
*/


function mytheme_theme_support(){
// Adds dynamic title tag support
add_theme_support("title-tag");
add_theme_support("custom-logo");
//add_theme_support("post-thumbnails");
add_theme_support("automatic-feed-links");

add_theme_support("align-wide");
add_theme_support("responsive-embeds");
add_theme_support("wp-block-styles");
}

add_action('after_setup_theme','mytheme_theme_support');




/*
//https://stackoverflow.com/questions/74862933/how-to-manually-create-a-text-domain-for-a-wordpress-child-theme
function mychildtheme_load_textdomain() {
load_child_theme_textdomain( 'simplehomepage', get_stylesheet_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'mychildtheme_load_textdomain' );
*/


function mytheme_menus(){
$locations = array(
'primary' => "Desktop Primary Menu",
//'footer' => "Footer Menu Items"
);

register_nav_menus($locations);
}

add_action('init', 'mytheme_menus');


function mytheme_register_styles(){

$varsion = wp_get_theme()->get('Version');
//wp_enqueue_style('main', get_template_directory_uri()."/assets/css/main.css",  array(), '1.0.0', 'all');
wp_enqueue_style('main', get_template_directory_uri()."/assets/css/main.css",  false, '1.0.0', 'all');
wp_enqueue_style('auto', get_template_directory_uri()."/assets/css/auto.css",  false, '1.0.0', 'all');
wp_enqueue_style('style', get_template_directory_uri()."/style.css",  false, '1.0.0', 'all');
}

add_action('wp_enqueue_scripts', 'mytheme_register_styles');



function mytheme_register_scripts(){
wp_enqueue_script('main', get_template_directory_uri()."/assets/js/main.js",  array(), '1.0.0', 'all');
}

add_action('wp_enqueue_scripts', 'mytheme_register_scripts');




/*
function mytheme_widget_areas(){

register_sidebar(
array(
'before_title' => '',
'after_title' => '',
'before_widget' => '',
'after_widget' => '',
),
array(
'name' => 'Sidebar Area',
'id' => 'sidebar-1',
'description' => 'Sidebar Widget Area',
)
);
}

add_action('widgets_init', 'mytheme_widget_areas');
*/







