<?php
get_header();
?>

<!-- page: single.php -->
<!--<h1 class="op tCenter">Post</h1>-->

<?php
if (have_posts()){
while (have_posts()){
the_post();
//the_content();
get_template_part('template-parts/content', 'article');
}
}
?>

<div class="margin2 padding2"></div>

<?php
//comments_number();
comments_template();
?>

<?php
get_footer();
?>

