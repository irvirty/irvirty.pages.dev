
<h1 class="op tCenter"><?php the_title(); ?></h1>


<?php

the_content();

//the_date();


?>

<?php
/*delme
<?php wp_link_pages(); ?>
*/
?>

<div class="margin2 padding2"></div>

<?php
//comments_number();
comments_template();
?>
