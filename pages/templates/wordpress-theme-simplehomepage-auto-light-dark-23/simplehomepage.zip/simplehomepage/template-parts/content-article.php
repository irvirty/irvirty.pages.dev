
<?php
/*
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<h2><?php the_title(); ?></h2>
*/

?>

<h1 class="tCenter op"><?php the_title(); ?></h1>

<article>
<div class="bgList border3List borderRadius2 tLeft">
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php
//the_excerpt();
the_content();
?>
</div>

<div class="postFooter break2 small clear padding3">
<span class="tagList tLeft left"><?php the_category( ', ' ).the_tags('<span> / ', ', ', '</span>'); ?></span>
<span class="tagList tRight right"><?php the_date(); echo " (".get_comments_number().")"; ?></span>
</div>

</div>
</article>

<div class="margin padding"></div>

<div class="bgList border3List borderRadius2">
<div class="postFooter break2 small">
<span class="button tLeft left"><?php previous_post_link(); ?></span>
<span class="button tRight right"><?php next_post_link(); ?></span>
</div>
</div>

<?php
//comments_number();
comments_template();
?>

