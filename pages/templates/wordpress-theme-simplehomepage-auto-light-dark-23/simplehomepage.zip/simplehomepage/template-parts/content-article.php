
<?php
/*
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
*/
?>


<article>
<div class="bgList border3List borderRadius2 padding3 tLeft">
<h2><?php the_title(); ?></h2>

<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<?php
//the_excerpt();
the_content();
?>
</div>

<div class="postFooter break2 small">
<span class="tagList tLeft left"><?php the_category( ', ' ).the_tags('<span> / ', ', ', '</span>'); ?></span>
<span class="tagList tRight right"><?php the_date(); echo " (".get_comments_number().")"; ?></span>
</div>

</div>
</article>


<?php
//comments_number();
comments_template();
?>

