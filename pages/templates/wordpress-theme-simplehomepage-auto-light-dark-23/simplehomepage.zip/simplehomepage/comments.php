
<!-- page: comments.php -->


<?php



if (!have_comments()){
///echo "Leave a Comment";
} else {

echo <<<EOF

<div class="padding2 margin2"></div>
<div class="light padding3 border borderRadius">
<div id="comments"></div>

EOF;

echo get_comments_number()." Comments:<br><br>";

wp_list_comments(
array(
'avatar_size' => 32,
'style' => 'ul',
)
);

echo "</div>";
}





?>


<?php
if (!have_comments()){
} else {
echo "<br>";
the_comments_pagination();
}
?>

<?php
if (comments_open()){

echo "<br>";

comment_form(
array(
'class_form' => ' op ',
'title_reply_before' => '<hr><h2 id="reply-title" class="comment-reply-title">',
'title_reply_after' => '</h2>'
)
);
}
?>



