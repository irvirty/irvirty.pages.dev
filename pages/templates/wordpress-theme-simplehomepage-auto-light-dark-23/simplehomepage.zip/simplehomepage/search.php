<?php
get_header();
?>

<!-- page: search.php -->
<h1 class="op tCenter">Search</h1>

<?php

$countFoundSearchResult = 0;
if (have_posts()){
while (have_posts()){
the_post();
//the_content();
get_template_part('template-parts/content', 'archive');
$countFoundSearchResult++;
}
} else {
echo '<h2 class="tCenter op">Not found</h2>';
}

//echo $countFoundSearchResult;
?>

<div class="wrapper">
<div class="padding margin"></div>


<div class="tCenter balance">
<?php
the_posts_pagination();
?>
</div>

<div class="padding margin"></div>
<?php get_search_form(); ?>
</div>

<?php
get_footer();
?>
