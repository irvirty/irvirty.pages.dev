<?php
get_header();
?>

<!-- page: search.php -->
<h1 class="op tCenter">Search</h1>

<?php


if (have_posts()){
while (have_posts()){
the_post();
//the_content();
get_template_part('template-parts/content', 'archive');
}
}


?>


<div class="padding margin"></div>
<?php the_posts_pagination(); ?>
<div class="padding margin"></div>
<?php get_search_form(); ?>
<?php
get_footer();
?>
