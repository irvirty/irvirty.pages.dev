<?php
get_header();
?>

<!-- page: search.php -->
<h1 class="op tCenter">Search</h1>

<?php

$countFoundSearchResult = 0;
if (have_posts()){
while (have_posts()){
the_post();
//the_content();
get_template_part('template-parts/content', 'archive');
$countFoundSearchResult++;
}
} else {
echo '<h2 class="tCenter op">Not found</h2>';
}

//echo $countFoundSearchResult;
?>

<div class="wrapper">
<div class="padding margin"></div>


<div class="tCenter balance">
<?php
the_posts_pagination();
?>
</div>


<?php
if (!is_page()){
?>
<div class="margin2 padding2"></div>
<div class="center">
<div class="tagList">
<?php wp_tag_cloud( array(
   'smallest' => 8, // size of least used tag
   'largest'  => 22, // size of most used tag
   'unit'     => 'px', // unit for sizing the tags
   'number'   => 45, // displays at most 45 tags
   'orderby'  => 'name', // order tags alphabetically
   'order'    => 'ASC', // order tags by ascending order
   'taxonomy' => 'post_tag' // you can even make tags for custom taxonomies
) );
?>
</div>
</div>
<div class="margin2 padding2"></div>
<?php
}
?>


<div class="padding margin"></div>
<?php get_search_form(); ?>
</div>

<?php
get_footer();
?>
