// WP theme, tutorial how to creat
https://www.youtube.com/watch?v=-h7gOJbIpmo
https://www.youtube.com/watch?v=V4lRaPuqoWY


== Copyright ==

License: CC BY-SA 4.0
License URI: https://creativecommons.org/licenses/by-sa/4.0/
Copyright, (C) 2025 Irvirty (for validation)
