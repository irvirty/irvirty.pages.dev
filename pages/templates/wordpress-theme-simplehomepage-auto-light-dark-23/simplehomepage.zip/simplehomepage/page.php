<?php
get_header();
?>

<!-- page: page.php -->

<?php
if (have_posts()){
while (have_posts()){
the_post();
//the_content();

get_template_part('template-parts/content', 'page');
}
}






?>
<?php
$args = array (
	'before'      		=> '<div class="page-links-XXX"><span class="page-link-text">' . __( 'More pages: ', 'textdomain' ) . '</span>',
	'after'       		=> '</div>',
	'link_before' 		=> '<span class="page-link">',
	'link_after'  		=> '</span>',
	'next_or_number'	=> 'next',
	'separator'			=> ' | ',
	'nextpagelink'		=> __( 'Next &raquo', 'textdomain' ),
	'previouspagelink'	=> __( '&laquo Previous', 'textdomain' ),
);

wp_link_pages( $args );
?>
<div class="padding2 margin2"></div>

</main>
<!-- // content -->

<?php
get_footer();
?>
