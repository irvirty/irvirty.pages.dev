
<!-- page: footer.php -->

</div>
</main>

<footer class="tCenter margin3List">
<div class="margin3 padding3"></div>
<nav>

<?php
//dynamic_sidebar('sidebar-1');
?>

<a class="padding brand" style="padding-left: 0;" href="<?php bloginfo('rss2_url'); ?>">RSS</a>
<!--<a class="padding brand" href="#">link example</a>
<a class="padding brand" href="#">link example</a>-->
<!--<span class="gray">Theme license:</span> <a class="brand inlineBlock padding" rel="license" href="https://creativecommons.org/licenses/by-sa/4.0/">CC BY-SA 4.0 *</a>-->
<span class="op padding small" style="padding-right: 0;"><!--2024-->2025</span>
</nav>
</footer>

<?php
wp_footer();
?>

</body>
</html>
