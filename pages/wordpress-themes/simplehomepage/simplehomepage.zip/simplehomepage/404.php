<?php
get_header();
?>

<h1 class="op tCenter">Page Not Found</h1>

<div class="margin2 padding2"></div>

<div class="wrapper">
<?php 
get_search_form();
?>
</div>

<?php
get_footer();
?>


