<?php
//<!-- page: footer.php -->
?>

</div>
</main>

<div class="wrapper3">
<footer class="margin3List">

<div class="margin3 padding3"></div>


<?php if ( is_active_sidebar( 'simplehomepage-sidebar-2' ) ) : ?>
<div class="clear"></div>
<div class="wrapper2 tLeft">
<aside>
	<div id="simplehomepage-sidebar-2" class="widget-area" role="complementary">
		<?php dynamic_sidebar( 'simplehomepage-sidebar-2' ); ?>
	</div><!-- #sidebar -->
</aside>
</div>
<div class="clear"></div>
<?php endif; ?>


<nav class="tCenter">

<a class="inlineBlock padding brand" style="padding-left: 0;" href="<?php bloginfo('rss2_url'); ?>">RSS</a>
<!--<a class="inlineBlock padding brand" href="#">link example</a>
<a class="inlineBlock padding brand" href="#">link example</a>-->
<!--<span class="gray">Theme license:</span> <a class="brand inlineBlock padding" rel="license" href="https://creativecommons.org/licenses/by-sa/4.0/">CC BY-SA 4.0 *</a>-->
<span class="inlineBlock padding"><?php
//https://stackoverflow.com/questions/18686523/display-wordpress-site-title
echo get_bloginfo( 'name' ); ?></span>
<span class="inlineBlock padding op small" style="padding-right: 0;"><?php echo date("Y"); ?>
</span>
</nav>
</footer>
</div>

	<!-- All the document's HTML goes first. -->
	<!-- Then last, before closing the body tag, add: -->
<?php wp_footer(); ?>
</body>
</html>


