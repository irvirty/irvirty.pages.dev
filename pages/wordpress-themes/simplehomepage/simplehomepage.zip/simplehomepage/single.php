<?php
get_header();
?>

<?php
if (have_posts()){
while (have_posts()){
the_post();
get_template_part('template-parts/content', 'article');
}
}
?>

<?php wp_link_pages(); ?>

<div class="margin padding"></div>

<?php
//https://stackoverflow.com/questions/2723433/wordpress-check-if-there-are-previous-posts-before-displaying-link
if(get_next_post()||get_previous_post()){
?>
<div class="light border3List borderRadius2 notUnderline">
<div class="twoColumn break2 small clear">
<div class="tLeft left padding2" style="border-right: 1px solid var(--d2);"><?php previous_post_link(); ?></div>
<div class="tRight right padding2"><?php next_post_link(); ?></div>
</div>
</div>
<?php
}
?>

<div class="margin2 padding2"></div>

<?php
//https://stackoverflow.com/questions/3054245/how-to-make-a-custom-template-in-wordpress-work-as-a-password-protected-page
if ( post_password_required() ) {
} else {
comments_template();
}
?>



<?php
if (!is_page()){

echo '<div class="margin2 padding2"></div>';

if (get_tags()){
?>

<div class="op tCenter small padding2">Tag cloud:</div>
<div class="center">
<div class="keepTagList">
<?php
wp_tag_cloud( array(
   'smallest' => 10, // size of least used tag
   'largest'  => 32, // size of most used tag
   'unit'     => 'px', // unit for sizing the tags
   'number'   => 45, // displays at most 45 tags
   'orderby'  => 'name', // order tags alphabetically
   'order'    => 'ASC', // order tags by ascending order
   'taxonomy' => 'post_tag' // you can even make tags for custom taxonomies
) );
?>
</div>
</div>
<?php
}
?>

<div class="padding2 margin2"></div>

<div class="wrapperSmall">
<?php get_search_form(); ?>
</div>

<?php
}
?>

<div class="margin2 padding2"></div>


<?php
get_footer();
?>

