=== SimpleHomepage ===
Contributors: Irvirty
Requires at least: 6.7
Requires PHP: 8.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==
An experimental, lightweight WordPress theme. It features a clean, flat, and minimalist design with a bright, light color palette. You can use it to create a blog, personal site, or microblog. (Note: Supports only a single-level navigation menu. Background with a random picture.) 

== Copyright ==
SimpleHomePage, (C) 2025 Irvirty.
Simplehomepage is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.


== Changelog ==

= 7.10.0 =
* Now only light theme




This theme bundles the following third-party resources:

== Resources ==
* main.css, light.css, main.js, bg.svg, circle.svg, line-chaotic.svg, deco-paper.svg, wood.png, grid.png, flower.png, flower-2.png - Irvirty, CC BY-SA 4.0, https://irvirty.pages.dev
* Roboto font: Copyright 2025 Google Apache License, Version 2.0

== Notes ==
In the beginning I used these lessons to create a theme:
How to Create a Custom WordPress Theme - Full Course - YouTube - https://www.youtube.com/watch?v=-h7gOJbIpmo
How to Create a Custom WordPress Theme - Full Course 2022 - YouTube - https://www.youtube.com/watch?v=V4lRaPuqoWY



