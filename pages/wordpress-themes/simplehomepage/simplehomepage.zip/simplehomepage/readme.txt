=== SimpleHomePage ===
Contributors: Irvirty
Requires at least: 6.7
Requires PHP: 8.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==
Simple flat experimental theme for WordPress. Auto light and dark theme. Note: The multi-level menu does not work and is displayed as a single-level menu.


== Copyright ==
SimpleHomePage, (C) 2025 Irvirty.
Simplehomepage is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.


== Changelog ==

= 7.1.0 =
* Fixed style. (edited)

= 6.2.0 =
* Removed the top sidebar panel (widget).

= 6.1.0 =
* Updated CSS (validator error)

= 6.0.0 =
* Fixed CSS style (top panel (edited))
* Updated CSS and class in post

= 5.3.0 =
* Some fixes: comment, screenshot



This theme bundles the following third-party resources:

=== Fonts ===
Roboto Font
License: Apache License Version 2.0, http://www.apache.org/licenses/
Reference: https://github.com/googlefonts/roboto-2
Source: https://fonts.google.com/specimen/Roboto

== Resources ==
main.css, auto.css, main.js, bg.svg, bg-dark.svg - Irvirty, CC BY-SA 4.0, https://irvirty.pages.dev


== Notes ==
In the beginning I used these lessons to create a theme:
How to Create a Custom WordPress Theme - Full Course - YouTube - https://www.youtube.com/watch?v=-h7gOJbIpmo
How to Create a Custom WordPress Theme - Full Course 2022 - YouTube - https://www.youtube.com/watch?v=V4lRaPuqoWY
