=== SimpleHomePage ===
Contributors: Irvirty
Requires at least: 6.7
Requires PHP: 8.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==
A simple flat light theme for WordPress (experimental). Blog theme, homepage theme, simple theme, light colors, flat theme, light theme, lightweight theme, clean theme. Note: The multi-level menu does not work and is displayed as a single-level menu.     

== Copyright ==
SimpleHomePage, (C) 2025 Irvirty.
Simplehomepage is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.


== Changelog ==

= 7.10.0 =
* Now only light theme




This theme bundles the following third-party resources:

== Resources ==
* main.css, auto.css, main.js, bg.svg, bg-dark.svg - Irvirty, CC BY-SA 4.0, https://irvirty.pages.dev
* .screenReader class in main.css: https://wordpress.org/ GPLv2 (or later)

== Notes ==
In the beginning I used these lessons to create a theme:
How to Create a Custom WordPress Theme - Full Course - YouTube - https://www.youtube.com/watch?v=-h7gOJbIpmo
How to Create a Custom WordPress Theme - Full Course 2022 - YouTube - https://www.youtube.com/watch?v=V4lRaPuqoWY



