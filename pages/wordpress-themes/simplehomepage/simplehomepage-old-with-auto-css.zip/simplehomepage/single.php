<?php
get_header();
?>

<?php
if (have_posts()){
while (have_posts()){
the_post();
get_template_part('template-parts/content', 'article');
}
}
?>

<?php wp_link_pages(); ?>

<div class="margin padding"></div>

<div class="light border3List borderRadius2 notUnderline">
<div class="keepPostFooter twoColumn  break2 small">
<span class="button left"><?php previous_post_link(); ?></span>
<span class="button right"><?php next_post_link(); ?></span>
</div>
</div>

<div class="margin2 padding2"></div>

<?php
//https://stackoverflow.com/questions/3054245/how-to-make-a-custom-template-in-wordpress-work-as-a-password-protected-page
if ( post_password_required() ) {
} else {
comments_template();
}
?>

<?php
get_footer();
?>

